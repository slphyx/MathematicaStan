(* Wolfram Language Init File *)

Get[ "CmdStan`CmdStan`"]