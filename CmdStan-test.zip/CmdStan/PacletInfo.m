(* Paclet Info File *)

(* created 2560/01/24*)

Paclet[
    Name -> "CmdStan",
    Version -> "0.0.1",
    MathematicaVersion -> "11.0",
    Extensions -> 
        {
            {"Documentation", Language -> "English"}
        }
]


